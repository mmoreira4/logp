﻿namespace AppSimProva_MiguelMoreira_2B1
{
    partial class FrmQuestao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblProd1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtProd1 = new System.Windows.Forms.TextBox();
            this.txtProd2 = new System.Windows.Forms.TextBox();
            this.lblProd2 = new System.Windows.Forms.Label();
            this.txtProd3 = new System.Windows.Forms.TextBox();
            this.lblProd3 = new System.Windows.Forms.Label();
            this.TxtPreco3 = new System.Windows.Forms.TextBox();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.TxtPreco2 = new System.Windows.Forms.TextBox();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.TxtPreco1 = new System.Windows.Forms.TextBox();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Parcela01 = new System.Windows.Forms.Label();
            this.Parcela04 = new System.Windows.Forms.Label();
            this.Parcela03 = new System.Windows.Forms.Label();
            this.Parcela02 = new System.Windows.Forms.Label();
            this.Parcela05 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(878, 100);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CadetBlue;
            this.panel2.Controls.Add(this.TxtPreco3);
            this.panel2.Controls.Add(this.lblPreco3);
            this.panel2.Controls.Add(this.TxtPreco2);
            this.panel2.Controls.Add(this.lblPreco2);
            this.panel2.Controls.Add(this.TxtPreco1);
            this.panel2.Controls.Add(this.lblPreco1);
            this.panel2.Controls.Add(this.txtProd3);
            this.panel2.Controls.Add(this.lblProd3);
            this.panel2.Controls.Add(this.txtProd2);
            this.panel2.Controls.Add(this.lblProd2);
            this.panel2.Controls.Add(this.txtProd1);
            this.panel2.Controls.Add(this.lblProd1);
            this.panel2.Location = new System.Drawing.Point(32, 139);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(474, 344);
            this.panel2.TabIndex = 1;
            // 
            // lblProd1
            // 
            this.lblProd1.AutoSize = true;
            this.lblProd1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProd1.Location = new System.Drawing.Point(19, 25);
            this.lblProd1.Name = "lblProd1";
            this.lblProd1.Size = new System.Drawing.Size(171, 40);
            this.lblProd1.TabIndex = 0;
            this.lblProd1.Text = "Produto 1 :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Segoe Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(612, 426);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 61);
            this.button1.TabIndex = 2;
            this.button1.Text = "Comprar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtProd1
            // 
            this.txtProd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProd1.Location = new System.Drawing.Point(26, 81);
            this.txtProd1.Name = "txtProd1";
            this.txtProd1.Size = new System.Drawing.Size(164, 29);
            this.txtProd1.TabIndex = 1;
            // 
            // txtProd2
            // 
            this.txtProd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProd2.Location = new System.Drawing.Point(26, 181);
            this.txtProd2.Name = "txtProd2";
            this.txtProd2.Size = new System.Drawing.Size(164, 29);
            this.txtProd2.TabIndex = 3;
            this.txtProd2.TextChanged += new System.EventHandler(this.TxtProd2_TextChanged);
            // 
            // lblProd2
            // 
            this.lblProd2.AutoSize = true;
            this.lblProd2.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProd2.Location = new System.Drawing.Point(19, 125);
            this.lblProd2.Name = "lblProd2";
            this.lblProd2.Size = new System.Drawing.Size(171, 40);
            this.lblProd2.TabIndex = 2;
            this.lblProd2.Text = "Produto 2 :";
            // 
            // txtProd3
            // 
            this.txtProd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProd3.Location = new System.Drawing.Point(26, 283);
            this.txtProd3.Name = "txtProd3";
            this.txtProd3.Size = new System.Drawing.Size(164, 29);
            this.txtProd3.TabIndex = 5;
            this.txtProd3.TextChanged += new System.EventHandler(this.TxtProd3_TextChanged);
            // 
            // lblProd3
            // 
            this.lblProd3.AutoSize = true;
            this.lblProd3.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProd3.Location = new System.Drawing.Point(19, 227);
            this.lblProd3.Name = "lblProd3";
            this.lblProd3.Size = new System.Drawing.Size(171, 40);
            this.lblProd3.TabIndex = 4;
            this.lblProd3.Text = "Produto 3 :";
            this.lblProd3.Click += new System.EventHandler(this.lblProd3_Click);
            // 
            // TxtPreco3
            // 
            this.TxtPreco3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPreco3.Location = new System.Drawing.Point(260, 283);
            this.TxtPreco3.Name = "TxtPreco3";
            this.TxtPreco3.Size = new System.Drawing.Size(164, 29);
            this.TxtPreco3.TabIndex = 11;
            this.TxtPreco3.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco3.Location = new System.Drawing.Point(253, 227);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(128, 40);
            this.lblPreco3.TabIndex = 10;
            this.lblPreco3.Text = "Preço 3:";
            this.lblPreco3.Click += new System.EventHandler(this.label3_Click);
            // 
            // TxtPreco2
            // 
            this.TxtPreco2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPreco2.Location = new System.Drawing.Point(260, 181);
            this.TxtPreco2.Name = "TxtPreco2";
            this.TxtPreco2.Size = new System.Drawing.Size(164, 29);
            this.TxtPreco2.TabIndex = 9;
            this.TxtPreco2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco2.Location = new System.Drawing.Point(253, 125);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(128, 40);
            this.lblPreco2.TabIndex = 8;
            this.lblPreco2.Text = "Preço 2:";
            this.lblPreco2.Click += new System.EventHandler(this.label4_Click);
            // 
            // TxtPreco1
            // 
            this.TxtPreco1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPreco1.Location = new System.Drawing.Point(260, 81);
            this.TxtPreco1.Name = "TxtPreco1";
            this.TxtPreco1.Size = new System.Drawing.Size(164, 29);
            this.TxtPreco1.TabIndex = 7;
            this.TxtPreco1.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco1.Location = new System.Drawing.Point(253, 25);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(136, 40);
            this.lblPreco1.TabIndex = 6;
            this.lblPreco1.Text = "Preço 1 :";
            this.lblPreco1.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel3.Controls.Add(this.Parcela05);
            this.panel3.Controls.Add(this.Parcela02);
            this.panel3.Controls.Add(this.Parcela03);
            this.panel3.Controls.Add(this.Parcela04);
            this.panel3.Controls.Add(this.Parcela01);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(552, 139);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(295, 281);
            this.panel3.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 37);
            this.label3.TabIndex = 0;
            this.label3.Text = "1° Parcela de :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 37);
            this.label4.TabIndex = 1;
            this.label4.Text = "2° Parcela de :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 37);
            this.label5.TabIndex = 2;
            this.label5.Text = "3° Parcela de :";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 37);
            this.label6.TabIndex = 3;
            this.label6.Text = "5° Parcela de :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 37);
            this.label7.TabIndex = 4;
            this.label7.Text = "4° Parcela de :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Parcela01
            // 
            this.Parcela01.AutoSize = true;
            this.Parcela01.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parcela01.Location = new System.Drawing.Point(175, 24);
            this.Parcela01.Name = "Parcela01";
            this.Parcela01.Size = new System.Drawing.Size(22, 29);
            this.Parcela01.TabIndex = 5;
            this.Parcela01.Text = "-";
            // 
            // Parcela04
            // 
            this.Parcela04.AutoSize = true;
            this.Parcela04.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parcela04.Location = new System.Drawing.Point(175, 173);
            this.Parcela04.Name = "Parcela04";
            this.Parcela04.Size = new System.Drawing.Size(22, 29);
            this.Parcela04.TabIndex = 6;
            this.Parcela04.Text = "-";
            // 
            // Parcela03
            // 
            this.Parcela03.AutoSize = true;
            this.Parcela03.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parcela03.Location = new System.Drawing.Point(175, 124);
            this.Parcela03.Name = "Parcela03";
            this.Parcela03.Size = new System.Drawing.Size(22, 29);
            this.Parcela03.TabIndex = 7;
            this.Parcela03.Text = "-";
            this.Parcela03.Click += new System.EventHandler(this.label2_Click);
            // 
            // Parcela02
            // 
            this.Parcela02.AutoSize = true;
            this.Parcela02.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parcela02.Location = new System.Drawing.Point(175, 72);
            this.Parcela02.Name = "Parcela02";
            this.Parcela02.Size = new System.Drawing.Size(22, 29);
            this.Parcela02.TabIndex = 8;
            this.Parcela02.Text = "-";
            // 
            // Parcela05
            // 
            this.Parcela05.AutoSize = true;
            this.Parcela05.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parcela05.Location = new System.Drawing.Point(175, 226);
            this.Parcela05.Name = "Parcela05";
            this.Parcela05.Size = new System.Drawing.Size(22, 29);
            this.Parcela05.TabIndex = 9;
            this.Parcela05.Text = "-";
            // 
            // FrmQuestao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(877, 495);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmQuestao1";
            this.Text = "Games";
            this.Load += new System.EventHandler(this.FrmQuestao1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox TxtPreco3;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.TextBox TxtPreco2;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.TextBox TxtPreco1;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.TextBox txtProd3;
        private System.Windows.Forms.Label lblProd3;
        private System.Windows.Forms.TextBox txtProd2;
        private System.Windows.Forms.Label lblProd2;
        private System.Windows.Forms.TextBox txtProd1;
        private System.Windows.Forms.Label lblProd1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Parcela05;
        private System.Windows.Forms.Label Parcela02;
        private System.Windows.Forms.Label Parcela03;
        private System.Windows.Forms.Label Parcela04;
        private System.Windows.Forms.Label Parcela01;
    }
}

