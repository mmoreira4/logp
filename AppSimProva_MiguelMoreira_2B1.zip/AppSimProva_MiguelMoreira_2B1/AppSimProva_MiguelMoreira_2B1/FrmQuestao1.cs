﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MiguelMoreira_2B1
{
    public partial class FrmQuestao1 : Form
    {
        public FrmQuestao1()
        {
            InitializeComponent();
        }

        private void TxtProd3_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblProd3_Click(object sender, EventArgs e)
        {

        }

        private void TxtProd2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            float Prod01 = float.Parse(TxtPreco1.Text);
            float Prod02 = float.Parse(TxtPreco2.Text);
            float Prod03 = float.Parse(TxtPreco3.Text);
            float soma;
            soma = Prod01 + Prod02 + Prod03;

            Parcela01.Text = "R$" + (soma).ToString("F");
            Parcela02.Text = "R$" + (soma / 2).ToString("F");
            Parcela04.Text = "R$" + (soma / 4).ToString("F");
            Parcela05.Text = "R$" + (soma / 5).ToString("F");
;
        }

        private void FrmQuestao1_Load(object sender, EventArgs e)
        {



        }
    }
}
